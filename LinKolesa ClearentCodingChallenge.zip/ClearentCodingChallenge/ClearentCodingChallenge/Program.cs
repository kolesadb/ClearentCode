﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace ClearantCodingChallenge
{
    #region ( Notes )
    //p=person
    //w=wallet
    //cc=credit card
    #endregion

    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, Person> People = new Dictionary<int, Person>();

            CreditCard cc = new CreditCard();
            Person p = new Person();
            Wallet w = new Wallet();

            //
            //
            //
            p = new Person("A");

            w = new Wallet();
            w.Cards.Add(1, new CreditCard(CreditCardType.Visa, 10.00, p.Name, 100));
            w.Cards.Add(2, new CreditCard(CreditCardType.MasterCard, 5.00, p.Name, 100));
            w.Cards.Add(3, new CreditCard(CreditCardType.Discover, 1.00, p.Name, 100));

            Debug.Print(w.Cards[1].Interest.ToString());
            Debug.Print(w.Cards[2].Interest.ToString());
            Debug.Print(w.Cards[3].Interest.ToString());

            Debug.Print(w.Interest.ToString());
            Console.WriteLine("msg");

            p.Wallets.Add(1, w);

            People.Add(1,p);
            Debug.Print(p.Interest.ToString());

            //
            //
            //
            p = new Person("B");

            w = new Wallet();
            w.Cards.Add(3, new CreditCard(CreditCardType.Visa, 10.00, p.Name, 100));
            w.Cards.Add(1, new CreditCard(CreditCardType.Discover, 1.00, p.Name, 100));
            Debug.Print(w.Interest.ToString());
            p.Wallets.Add(1, w);

            w = new Wallet();
            w.Cards.Add(2, new CreditCard(CreditCardType.MasterCard, 5.00, p.Name, 100));
            Debug.Print(w.Interest.ToString());
            p.Wallets.Add(2, w);

            People.Add(2, p);
            Debug.Print(p.Interest.ToString());

            //
            //
            //
            p = new Person("C");

            w = new Wallet();
            w.Cards.Add(3, new CreditCard(CreditCardType.Visa, 10.00, p.Name, 100));
            w.Cards.Add(1, new CreditCard(CreditCardType.Discover, 1.00, p.Name, 100));
            w.Cards.Add(2, new CreditCard(CreditCardType.MasterCard, 5.00, p.Name, 100));

            Debug.Print(w.Cards[3].Interest.ToString());
            Debug.Print(w.Cards[1].Interest.ToString());
            Debug.Print(w.Cards[2].Interest.ToString());
            Debug.Print(w.Interest.ToString());
            p.Wallets.Add(1, w);

            Debug.Print(p.Interest.ToString());
            People.Add(3, p);

            //
            p = new Person("D");
            w = new Wallet();

            w.Cards.Add(3, new CreditCard(CreditCardType.Visa, 10.00, p.Name, 100));
            w.Cards.Add(2, new CreditCard(CreditCardType.MasterCard, 5.00, p.Name, 100));
            Debug.Print(w.Interest.ToString());
            p.Wallets.Add(2, w);

            Debug.Print(p.Interest.ToString());
            People.Add(4, p);

            //
            double totalInterest = CalcTotalInterest(People);
            Debug.Print("Total Interest: " + totalInterest.ToString());
            
        }

        static public double CalcTotalInterest(Dictionary<int, Person> customers)
        {
            double tInterest = 0;
            double pInterest = 0;

            foreach (Person p in customers.Values)
            {
                tInterest = p.Interest;
                //tIinterest += pInterest;
            }

            return tInterest;
        }
    }


    public class BaseClass
    {
        public BaseClass()
        {
        }
        //
        //common methods
        //
    }

    public class CreditCard : BaseClass
    {
        public double Balance = 0.00;
        private double _rate = 0.00;
        private CreditCardType _type = CreditCardType.Undefined;
        private string _ownerName = "( not supplied )";

        public double Rate
        {
            get { return _rate; }
        }
        public CreditCardType Type
        {
            get { return _type; }
        }
        
        public double Interest
        {
            get { return Math.Round((Balance * Rate / 100),2); }
        }


        public CreditCard()
        {
        }

        public CreditCard(CreditCardType type, double rate, string ownerName, double balance )
        {
            _type = type;
            if (rate < 0)
            {
            }
            else
            {
                _rate = rate;
            }
            Balance = balance;
            _ownerName = ownerName;
        }
    }

    public class Wallet : BaseClass
    {
        public Dictionary<int,CreditCard> Cards = new Dictionary<int,CreditCard>();

        public Wallet()
        {
        }

        public double Interest
        {
            get {

                double x = 0;
                foreach (CreditCard cc in Cards.Values)
                {
                    x += cc.Interest;
                }
                return x; 
            }
        }
    }

    public class Person : BaseClass
    {
        public Dictionary<int, Wallet> Wallets = new Dictionary<int,Wallet>();

        public string Name = "";

        public Person()
        {
        }

        public Person(string name)
        {
            Name = name;
        }

        public double Interest
        {
            get {

                double x = 0;
                foreach (Wallet w in Wallets.Values)
                {
                    x += w.Interest;
                }
                return x; 
            }
        }
    
    }

    public enum CreditCardType
    {
        Undefined = 0,
        Visa =1,
        Discover = 2,
        MasterCard = 3
    }
}
